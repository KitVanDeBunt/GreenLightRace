#ifndef __RAK_SLEEP_H
#define __RAK_SLEEP_H

#include "Export.h"

void RAK_DLL_EXPORT RakSleep(unsigned int ms);

#endif
